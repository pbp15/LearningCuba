<template>
    <div class="container-fluid">

        <div class="card col-md-4 " style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title text-center">Eventos</h5>            
            </div>
        </div>

        <div class="card col-md-4 " style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title text-center">Noticias</h5>            
            </div>
        </div>

        <div class="card col-md-4 " style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title text-center">Blog</h5>            
            </div>
        </div>

         <div class="card col-md-4 " style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title text-center">Personas</h5>            
            </div>
        </div>

          <div class="card col-md-4 " style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title text-center">Usuarios</h5>            
            </div>
        </div>

        
          <div class="card col-md-4 " style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title text-center">Roles</h5>            
            </div>
        </div>

     </div>        
</template>

<script>

</script>
<style>    

</style>
