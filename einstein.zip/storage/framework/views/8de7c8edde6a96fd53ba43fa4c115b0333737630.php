
		<section class="home-slider owl-carousel">
			<div class="slider-item" style="background-image:url(images/portada3.jpg);">
				<div class="overlay"></div>
				<div class="container">
					<div class="row no-gutters slider-text align-items-center justify-content-start" data-scrollax-parent="true">
						<div class="col-md-6 ftco-animate">
							<h1 class="mb-4">Admision 2021 
							</h1>
							<p> I.E.P "Einstein - "Dios, ciencia y verdad"</p>
							<p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Ver mas</a></p>
						</div>
					</div>
				</div>
			</div>
		
			<div class="slider-item" style="background-image:url(images/portada2.jpg);">
				<div class="overlay"></div>
				<div class="container">
					<div class="row no-gutters slider-text align-items-center justify-content-start" data-scrollax-parent="true">
						<div class="col-md-6 ftco-animate">
							<h1 class="mb-4">....</h1>
							<p>Lema de la </p>
							<p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Ver mas</a></p>
						</div>
					</div>
				</div>
			</div>
		</section><?php /**PATH C:\Proyectos-Piero\Laravel-Webeinstein\Virtual-sistema\resources\views/paginaweb/carrusel.blade.php ENDPATH**/ ?>