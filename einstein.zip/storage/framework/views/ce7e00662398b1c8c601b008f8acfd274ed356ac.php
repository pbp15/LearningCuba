 
 <?php $__env->startSection('contenido'); ?>


    <?php if(Auth::check()): ?>
            <?php if(Auth::user()->idrol == 1): ?>
                
                            <!-- Contenido Principal -->
                            <template  v-if="menu==0">
                                <h1>Escritorio</h1>           
                            </template>

                            <template  v-if="menu==1">
                                <oficina></oficina>
                            </template>

                            <template  v-if="menu==2">
                                <user></user>
                            </template>

                            <template  v-if="menu==3">
                                <h1>Contenido Nº3 </h1>
                            </template>

                            <template  v-if="menu==4">
                                <rol></rol>
                            </template>

                            <template  v-if="menu==5">
                                <expediente></expediente>
                            </template>

                            <template  v-if="menu==6">
                                <usuarioexpediente></usuarioexpediente>
                            </template>

                            <template  v-if="menu==7">
                                <h1>Contenido Nº7 </h1>
                            </template>

                            <template  v-if="menu==8">
                                <h1>Contenido Nº8 </h1>
                            </template>

                            <template  v-if="menu==9">
                                <h1>Contenido Nº9 </h1>
                            </template>

                            <template  v-if="menu==10">
                                <h1>Contenido Nº10 </h1>
                            </template>

                            <template  v-if="menu==11">
                                <h1>Contenido Nº11 </h1>
                            </template>

                            <template  v-if="menu==12">
                                <h1>Contenido Nº12 </h1>
                            </template>
                            <template  v-if="menu==13">
                                <persona></persona>
                            </template>
                            <!-- /Fin del contenido principal -->
            
            <?php elseif(Auth::user()->idrol == 2): ?>
                    <!-- Contenido Principal -->
                    <template  v-if="menu==0">
                        <h1>Escritorio</h1>           
                    </template>
                    <template  v-if="menu==1">
                        <oficina></oficina>
                    </template>   

                    <template  v-if="menu==5">
                        <expediente></expediente>
                    </template>

                    <template  v-if="menu==6">
                        <usuarioexpediente></usuarioexpediente>
                    </template>

            
            <!-- /Fin del contenido principal -->
            <?php elseif(Auth::user()->idrol == 3): ?>
                    <!-- Contenido Principal -->
                    <template  v-if="menu==0">
                        <h1>Escritorio</h1>           
                    </template>

                    <template  v-if="menu==5">
                        <expediente></expediente>
                    </template>

                    <template  v-if="menu==6">
                        <usuarioexpediente></usuarioexpediente>
                    </template>
            
            <?php elseif(Auth::user()->idrol == 4): ?>
                    <template  v-if="menu==0">
                        <h1>Escritorio</h1>           
                    </template>

                    <template  v-if="menu==5">
                        <expediente></expediente>
                    </template>

                    <template  v-if="menu==6">
                        <usuarioexpediente></usuarioexpediente>
                    </template>
            <?php else: ?>

      <?php endif; ?>

    <?php endif; ?>


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos-Piero\Laravel-VirtualMesa\Virtual-sistema\resources\views/contenido/contenido.blade.php ENDPATH**/ ?>